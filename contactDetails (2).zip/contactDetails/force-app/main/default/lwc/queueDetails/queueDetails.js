import { LightningElement,wire ,track} from 'lwc';
import getQueues from '@salesforce/apex/ContactDetails.getQueues';
import { getObjectInfo } from 'lightning/uiObjectInfoApi';

import { getPicklistValues } from 'lightning/uiObjectInfoApi';
import list_view__c_FIELD from '@salesforce/schema/Queues__c.list_view__c';

import Queues__c_OBJECT from '@salesforce/schema/Queues__c';


export default class queueDetails extends LightningElement {
    @track pickListvalues;
    @track error;
    @track values;
    @track pickListvaluesByRecordType;
    @track accountsource;
    @wire(getQueues) Queueslist;
    boolVisible;
    Select = true;
    visibleContacts
    totalContacts
    clickedButtonLabel = 'View More';
    value ='Pending Agreement Actions';
    handleLoad(event){
        const rowId = event.target.dataset.id;
        console.log('rowId=='+rowId);
        console.log('rowId=='+this.template.querySelector(`div[data-id="${rowId}"]`));
        this.template.querySelector(`div[data-id="${rowId}"]`).classList.toggle('slds-hide'); 
        const label = event.target.label;  
    
        if ( label === 'View More' ) {  
            this.template.querySelector(`lightning-button[data-id="${rowId}"]`).label = 'View Less';  
            this.boolVisible = true;  

        } else if  ( label === 'View Less' ) {  
            this.template.querySelector(`lightning-button[data-id="${rowId}"]`).label = 'View More';  
            this.boolVisible = false;  

        }  
    } 

    @wire(getObjectInfo,{
        objectApiName : Queues__c_OBJECT
    })
        wiredObject({data, error}){
            if(data){
            }
            if(error){
                console.log(error);
            }
        }

    @wire(getPicklistValues, 
        {
            recordTypeId: '012000000000000AAA',
        fieldApiName : list_view__c_FIELD
    })
        wiredPickListValue({ data, error }){
            if(data){
                console.log(` Picklist values are `, data.values);
                this.pickListvalues = data.values;
                this.error = undefined;
            }
            if(error){
                console.log(` Error while fetching Picklist values  ${error}`);
                this.error = error;
                this.pickListvalues = undefined;
            }
        }

    handleChange(event) {
        const value=event.target.value
        if(value==="Pending Agreement Actions"){
            this.Select=true;
            this.value = event.detail.value;
      }else{this.Select=false}

    }
    updateContactHandler(event){
        this.visibleContacts=[...event.detail.records]
        console.log(event.detail.records)
    }
}