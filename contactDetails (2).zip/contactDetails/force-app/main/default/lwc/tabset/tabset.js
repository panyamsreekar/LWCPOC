import { LightningElement } from 'lwc';

export default class Tabset extends LightningElement {}