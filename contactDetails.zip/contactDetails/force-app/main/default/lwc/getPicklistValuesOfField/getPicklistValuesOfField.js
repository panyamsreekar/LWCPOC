import { LightningElement,wire } from 'lwc';

import { getObjectInfo } from 'lightning/uiObjectInfoApi';

import { getPicklistValues } from 'lightning/uiObjectInfoApi';

import Queues__c_OBJECT from '@salesforce/schema/Queues__c';

import list_view__c_FIELD from '@salesforce/schema/Queues__c.list_view__c';

export default class getPicklistValuesOfField extends LightningElement {

    value ='';

    // to get the default record type id, if you dont' have any recordtypes then it will get master

    @wire(getObjectInfo, { objectApiName: Queues__c_OBJECT })

    Queues__cMetadata;

    // now get the industry picklist values

    @wire(getPicklistValues,

        {

        

            fieldApiName: list_view__c_FIELD

        }

    )

    list_viewPicklist;

    // on select picklist value to show the selected value

    handleChange(event) {

        this.value = event.detail.value;

    }

}