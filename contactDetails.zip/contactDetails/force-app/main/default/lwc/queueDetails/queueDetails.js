import { LightningElement,wire ,track} from 'lwc';
import getQueues from '@salesforce/apex/ContactDetails.getQueues';
import { getObjectInfo } from 'lightning/uiObjectInfoApi';

import { getPicklistValues } from 'lightning/uiObjectInfoApi';
import list_view__c_FIELD from '@salesforce/schema/Queues__c.list_view__c';

import Queues__c_OBJECT from '@salesforce/schema/Queues__c';


export default class queueDetails extends LightningElement {
    @track pickListvalues;
    @track error;
    @track values;
    @track pickListvaluesByRecordType;
    @track accountsource;
  @wire(getQueues) Queueslist;
  boolVisible;
  Select;
  visibleContacts
  totalContacts
  clickedButtonLabel = 'View More';
  handleLoad(event){
    const label = event.target.label;  
  
    if ( label === 'View More' ) {  

        this.clickedButtonLabel = 'View Less';  
        this.boolVisible = true;  

    } else if  ( label === 'View Less' ) {  
          
        this.clickedButtonLabel = 'View More';  
        this.boolVisible = false;  

    }  
  } 
value ='';

    // to get the default record type id, if you dont' have any recordtypes then it will get master

    @wire(getObjectInfo,{
        objectApiName : Queues__c_OBJECT
    })
        wiredObject({data, error}){
            if(data){
                console.log(' Object iformation ', data);
                console.table(data);
            }
            if(error){
                console.log(error);
            }
        }


    // now get the industry picklist values

    @wire(getPicklistValues, 
        {
            recordTypeId: '012000000000000AAA',
        fieldApiName : list_view__c_FIELD
    })
        wiredPickListValue({ data, error }){
            if(data){
                console.log(` Picklist values are `, data.values);
                this.pickListvalues = data.values;
                this.error = undefined;
            }
            if(error){
                console.log(` Error while fetching Picklist values  ${error}`);
                this.error = error;
                this.pickListvalues = undefined;
            }
        }

    // on select picklist value to show the selected value

    handleChange(event) {
        const value=event.target.value
        if(value==="Pending Agreement Actions"){
            this.Select=true;
            this.value = event.detail.value;
      }else{this.Select=false}

}
updateContactHandler(event){
    this.visibleContacts=[...event.detail.records]
    console.log(event.detail.records)
}
}


